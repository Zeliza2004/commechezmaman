/*
var formValidation = document.getElementById('bouton_inscription');
var rgpd = document.getElementById('rgpd');

rgpd.addEventListener("change", function(event){

	if (event.target.checked){
		console.log("check");
		formValidation.disabled = false;
	}else{
		formValidation.disabled = true;
		console.log("no-check");
	}
	}, false);

*/

let btnAdd = document.querySelector('#buttoningredient');
let table = document.querySelector('#table_ingredient');


btnAdd.addEventListener('click', () => {

	let template = `
                <tr>
					<td>
						<div class="form-group">
							<label for="ingredient" class="col-md-2 control-label"></label>
								<div class="col-md-10 ">
									<span class="help-block"></span>
									<input type="text" name="ingredient1" value="" id="ingredient" class="form-control">
								</div>
						</div>
					</td>
					<td>
						<div class="form-group">
							<label for="grammage" class="col-md-2 control-label"></label>
								<div class="col-md-10 ">
									<span class="help-block"></span>
									<input type="text" name="quantite1" value="" id="grammage" class="form-control">
								</div>
						</div>
					</td>
					<td>
						<div class="form-group">
							<label for="unite_de_mesure" class="col-md-2 control-label"></label>
								<div class="col-md-10 ">
									<span class="help-block"></span>
									<input type="text" name="unite_de_mesure1" value="" id="unite_de_mesure" class="form-control" >
								</div>
						</div>
					</td>
				</tr>`;

	table.innerHTML += template;
});

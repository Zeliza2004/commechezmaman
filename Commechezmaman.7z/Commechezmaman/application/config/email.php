<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']  = 'smtp';
$config['smtp_host'] = 'ssl://smtp.googlemail.com';
$config['smtp_user'] = 'promodevweb@gmail.com';
$config['smtp_pass'] = 'tetris2020';
$config['smtp_port'] = 465;
$config['charset']   = 'utf-8';
$config['mailtype']  = 'html';
$config['newline']   = "\r\n";


<?php
class Recette extends CI_Model {

	function ingredientrecette ($id_recette)
	{
	$this->db-> where('id_recette', $id_recette	);
	return $this->db->get('ingredient')->result_array();
	}

	function etaperecette()
	{
	return $this->db->get('etapesrecette')->result_array();
	}

}

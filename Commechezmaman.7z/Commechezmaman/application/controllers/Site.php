<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Site extends CI_Controller
{

	public function inscription()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Inscription";

		$this->form_validation->set_rules('nom', 'Nom', 'trim|required|min_length[5]|max_length[12]|is_unique[utilisateur.nom]');
		$this->form_validation->set_rules('prenom', 'Prénom', 'trim|required|min_length[5]|max_length[12]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
		$this->form_validation->set_rules('password2', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('Adresse_mail', 'Adresse_mail', 'trim|required|valid_email|is_unique[utilisateur.Adresse_mail]');
		$this->form_validation->set_rules('rgpd', 'Rgpd', 'required');

		if ($this->form_validation->run() == TRUE) {
			$datadb = array(
				'nom' => $this->input->post('nom', TRUE),
				'prenom' => $this->input->post('prenom', TRUE),
				'adresse_mail' => $this->input->post('Adresse_mail', TRUE),
				'password' => password_hash($this->input->post('password', TRUE), PASSWORD_BCRYPT),
			);
			$this->db->insert('utilisateur', $datadb);
		}
		/*if ($this->form_validation->send) {
			redirect('connexion');
		} else {
			$data['login_error'] = "Échec de l'inscription";
		}*/
		$this->load->view('common/header', $data);
		$this->load->view('site/inscription', $data);
		$this->load->view('common/footer', $data);
	}

	public function connexion()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Identification";
		if ($this->form_validation->run()) {
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$this->db->select('prenom');
			$this->db->from('utilisateur');
			$this->db->where('prenom', $username);
			$query = $this->db->get();   //->$password a tester
			foreach ($query->result() as $row) {
				$hash = $this->auth_user->load_user($username)->password;
				if (password_verify($password, $hash)) {                                                    // on check si le hash match avec le password saisi
					$this->auth_user->utilisateur($username, $password);
					if ($this->auth_user->is_connected) {
						redirect('index');
					} else {
						$data['login_error'] = "Échec de l'authentification";
					}
				}
			}
		}

		$this->load->view('common/header', $data);
		$this->load->view('site/connexion', $data);
		$this->load->view('common/footer', $data);
	}

	public function resetpassword()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Réinitialisation mot de passe";



		$this->load->view('common/header', $data);
		$this->load->view('site/resetpassword', $data);
		$this->load->view('common/footer', $data);
	}

	public function contact()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Contact";
		$this->load->view('common/header', $data);
		if ($this->form_validation->run()) {
			$this->load->library('email');
			$this->email->from($this->input->post('email'), $this->input->post('name'));
			$this->email->to('canuel.stephanie@gmail.com');
			$this->email->subject($this->input->post('title'));
			$this->email->message($this->input->post('message'));
			if ($this->email->send()) {
				$data['result_class'] = "alert-success";
				$data['result_message'] = "Merci de nous avoir envoyé ce mail. Nous y répondrons dans les meilleurs délais.";
			} else {
				$data['result_class'] = "alert-danger";
				$data['result_message'] = "Votre message n'a pas pu être envoyé. Nous mettons tout en oeuvre pour résoudre le problème.";
				$this->email->clear();
			}
			$this->load->view('site/contact_result', $data);
		} else {
			$this->load->view('site/contact', $data);
		}
		$this->load->view('common/footer', $data);
	}

	function deconnexion()
	{
		$this->auth_user->logout();
		redirect('index');
	}

	public function index()
	{

		$data["title"] = "Accueil";

		$this->load->view('common/header', $data);
		$this->load->view('site/index', $data);
		$this->load->view('common/footer', $data);
	}

	public function politique()
	{
		$data["title"] = "Politique de confidentialité";

		$this->load->view('common/header', $data);
		$this->load->view('site/politique', $data);
		$this->load->view('common/footer', $data);
	}
}

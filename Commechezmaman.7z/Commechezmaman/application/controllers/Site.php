<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Site extends CI_Controller
{

	public function inscription()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Inscription";

		$this->form_validation->set_rules('nom', 'Nom', 'trim|required|min_length[5]|max_length[12]|is_unique[utilisateur.nom]');
		$this->form_validation->set_rules('prenom', 'Prénom', 'trim|required|min_length[5]|max_length[12]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
		$this->form_validation->set_rules('password2', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('Adresse_mail', 'Adresse_mail', 'trim|required|valid_email|is_unique[utilisateur.Adresse_mail]');
		$this->form_validation->set_rules('rgpd', 'Rgpd', 'required');

		if ($this->form_validation->run() == TRUE) {
			$datadb = array(
				'nom' => $this->input->post('nom', TRUE),
				'prenom' => $this->input->post('prenom', TRUE),
				'adresse_mail' => $this->input->post('Adresse_mail', TRUE),
				'password' => password_hash($this->input->post('password', TRUE), PASSWORD_BCRYPT),
			);
			$this->db->insert('utilisateur', $datadb);
		}
		/*if ($this->form_validation->send) {
			redirect('connexion');
		} else {
			$data['login_error'] = "Échec de l'inscription";
		}*/
		$this->load->view('common/header', $data);
		$this->load->view('site/inscription', $data);
		$this->load->view('common/footer', $data);
	}

	public function connexion()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Identification";
		if ($this->form_validation->run()) {
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$this->db->select('prenom');
			$this->db->from('utilisateur');
			$this->db->where('prenom', $username);
			$query = $this->db->get();
			foreach ($query->result() as $row) {
				$hash = $this->auth_user->load_user($username)->password;
				if (password_verify($password, $hash)) {                                                    // on check si le hash match avec le password saisi
					$this->auth_user->utilisateur($username, $password);
					if ($this->auth_user->is_connected) {
						redirect('index');
					} else {
						$data['login_error'] = "Échec de l'authentification";
					}
				}
			}
		}
		$this->load->view('common/header', $data);
		$this->load->view('site/connexion', $data);
		$this->load->view('common/footer', $data);
	}

	public function resetpassword()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');

		$data["title"] = "Réinitialisation mot de passe";
		$message = null ; // message qui servira à indiquer à l'utilisateur si l'email a été envoyé

			if (isset($_POST['adresse_mail'])) // on check si on trouve bien le username dans le POST
			{
				$mail = htmlspecialchars($_POST['adresse_mail']); // username == email, on récupère l'email
				// Et on essaie de récupérer l'utilisateur correspondant à cet email'
				$this->db->from('utilisateur');
				$this->db->where('adresse_mail', $mail);
				$query = $this->db->get();
				foreach ($query->result() as $user) {
					$token = bin2hex(random_bytes(32)); // on génère un token, des milliers de méthodes sont acceptables
					// on créé le lien qui sera envoyé à l'utilisateur (à adapter suivant vos serveurs)
					$link = "http://localhost/Commechezmaman/newpassword?id=" . $user->id . "&token=" . $token;
					// corps de l'email
					$body = "Merci de cliquer sur le lien suivant pour réinitialiser votre mot de passe : <a href='$link'>$link</a>";
					// envoi de l'email à l'utilisateur
					if ($this->form_validation->run()) {
						$this->load->library('email');
						$this->email->from('promodevweb@gmail.com','Comme chez maman');
						$this->email->to($mail);
						$this->email->subject("Réinitialisation mot de passe");
						$this->email->message($body);
						if ($this->email->send()) {
							$data['result_class'] = "alert-success";
							$data['result_message'] = "Un lien de réinitialisation du mot de passe a été envoyé par email si cet email correspond a un utilisateur inscrit";
						} else {
							$data['result_class'] = "alert-danger";
							$data['result_message'] = "Votre message n'a pas pu être envoyé. Nous mettons tout en oeuvre pour résoudre le problème.";
							$this->email->clear();
						}

						$database = array(
							'last_token' => $token,   // on ne retient que le dernier token généré, ainsi les précédents token ne pourront pas être utilisés
							'expiration_token' => date("Y-m-d H:i:s", strtotime("+30 min")), // le token sera valide 30 minutes
						);
						$this->db->where('adresse_mail', $mail);
						$this->db->update('utilisateur', $database);// on met aussi à jour l'utilisateur en base de données en rajoutant le token et sa date d'expiration
					}
				}
			}
		$this->load->view('common/header', $data);
		$this->load->view('site/resetpassword', $data);
		$this->load->view('common/footer', $data);
	}

	public function newpassword() {
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Nouveau mot de passe";

		$error_message = null ; // variable qui servira à la fois à savoir s'il y a eu une erreur, et son message d'erreur
		$valid_message = null ; // si l'opération a réussi, on voudra aussi afficher un message de succès
		$id = null ;
		$token = null ;

		// si l'url ne contenait pas d'id --> erreur
		if (!isset($_GET["id"]) || !isset($_GET["token"])){
			$error_message = "Identifiant utilisateur ou Token invalide" ;
		}
		// l'url doit aussi contenir un token, sinon erreur
		else {
						$id = htmlspecialchars($_GET["id"]);
						$token = htmlspecialchars($_GET["token"]);
						$this->db->where('id', $id);
						$this->db->where('last_token', $token);
						$query=$this->db->get('utilisateur');
						foreach ($query->result() as $user) {
							if (isset($_POST["pwd"]) && isset($_POST["pwd2"])) { // on les récupère
								$pwd = htmlspecialchars($_POST["pwd"]);
								$pwd2 = htmlspecialchars($_POST["pwd2"]);
								if (empty($pwd) || empty($pwd2)) {
									// si l'un des deux mots de passe est vide, erreur
									$error_message = "Le mot de passe saisit ne doit pas être vide";
								} else if ($pwd !== $pwd2) {
									// si les deux mots de passes sont différents, erreur
									$error_message = "Vous devez saisir deux fois le même mot de passe";
								} else { // si on est là, c'est que tout est bon ! On termine
									// et on update l'utilisateur en mettant à jour le password et en faisant un reset du token pour le rendre à l'avenir inutilisable
									$datadb = array(
									'last_token' => NULL,
									'password' => password_hash($pwd, PASSWORD_BCRYPT),
									);
									$this->db->where('id', $id);
									$this->db->update('utilisateur', $datadb);
									// enfin, on définit un message de succès
									redirect ('connexion');
								}
							}
						}
				}
			$data['id'] = $id;
			$data['token'] = $token ;
			$data['error_message'] = $error_message;
			$data['valid_message'] = $valid_message;
			$this->load->view('common/header', $data);
			$this->load->view('site/newpassword', $data);
			$this->load->view('common/footer', $data);
	}


	public function contact()
	{
		$this->load->helper("form");
		$this->load->library('form_validation');
		$data["title"] = "Contact";
		$this->load->view('common/header', $data);
		if ($this->form_validation->run()) {
			$this->load->library('email');
			$this->email->from($this->input->post('email'), $this->input->post('name'));
			$this->email->to('canuel.stephanie@gmail.com');
			$this->email->subject($this->input->post('title'));
			$this->email->message($this->input->post('message'));
			if ($this->email->send()) {
				$data['result_class'] = "alert-success";
				$data['result_message'] = "Merci de nous avoir envoyé ce mail. Nous y répondrons dans les meilleurs délais.";
			} else {
				$data['result_class'] = "alert-danger";
				$data['result_message'] = "Votre message n'a pas pu être envoyé. Nous mettons tout en oeuvre pour résoudre le problème.";
				$this->email->clear();
			}
			$this->load->view('site/contact_result', $data);
		} else {
			$this->load->view('site/contact', $data);
		}
		$this->load->view('common/footer', $data);
	}

	function deconnexion()
	{
		$this->auth_user->logout();
		redirect('index');
	}

	public function index()
	{

		$data["title"] = "Accueil";

		$this->load->view('common/header', $data);
		$this->load->view('site/index', $data);
		$this->load->view('common/footer', $data);
	}

	public function politique()
	{
		$data["title"] = "Politique de confidentialité";

		$this->load->view('common/header', $data);
		$this->load->view('site/politique', $data);
		$this->load->view('common/footer', $data);
	}
}

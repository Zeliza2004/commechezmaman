<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Blog extends CI_Controller
{

	public function recueil()
	{

		$data["title"] = "Recueil de recette";

		$this->load->view('common/header', $data);
		$this->load->view('blog/recueil', $data);
		$this->load->view('common/footer', $data);
	}

	public function recettes()
	{


		$data["title"] = "Recettes";

		$this->load->view('common/header', $data);
		$this->load->view('blog/recettes', $data);
		$this->load->view('common/footer', $data);
	}

	public function ajoutrecette()
	{
		$data["title"] = "Ajouter votre recette";
		$this->load->helper("form");
		$this->load->library('form_validation');
		$this->load->library('upload');
		$this->load->helper('array');
		$this->form_validation->set_rules('nom_recette', 'nom_recette', 'required');

		if ($this->form_validation->run() == TRUE) {

			$datadb = array(
				'nom_recette' => $this->input->post('nom_recette', TRUE),
			);
			$this->db->insert('recette', $datadb);
			$id_recette = $this->db->insert_id();

			$datadb = array(
				'ingredient' => $this->input->post('ingredient1', TRUE),
				'quantite' => $this->input->post('quantité1', TRUE),
				'unite_de_mesure' => $this->input->post('unite_de_mesure1', TRUE),
			);

			$this->db->insert('ingredient_recette', $datadb);
var_dump($id_recette, $datadb);
		}


		/*
		'etapesrecette' = $this->input->post('description_etape');
		'numero_etape' = $this->input->post('numero_etape');

*/
		$this->load->view('common/header', $data);
		$this->load->view('blog/ajoutrecette', $data);
		$this->load->view('common/footer', $data);
	}

}

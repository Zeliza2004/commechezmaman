<div class="jumbotron">
	<div class="container">
		<h1><?= $title ?></h1>
		<h3>ARTICLE 1&nbsp;: PRÉAMBULE</h3>
		<p>Cette politique de confidentialité s'applique au site : Comme Chez Maman</p>

	</div>
</div>

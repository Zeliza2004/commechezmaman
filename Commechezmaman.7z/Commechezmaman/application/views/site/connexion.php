<div class="container text-center py-5">

	<h1><?= $title ?></h1>
</div>
<div class="container">

	<?= form_open('connexion', ['class' => 'form-horizontal']); ?>
	<?php if (!empty($login_error)) : ?>
		<div class="form-group">
			<div class="col-md-offset-2 col-md-10 has-error">
				<span class="help-block"><?= $login_error ?></span>
			</div>
		</div>
	<?php endif; ?>
	<div class="row">
		<div class="col-12">
			<div class="form-group form-inline">
				<?= form_label("Prénom utilisateur&nbsp;:", "username", ['class' => "col-md-3 control-label"]) ?>
				<div class="col-md-8 <?= empty(form_error('username')) ? "" : "has-error" ?>">
					<?= form_input(['name' => "username", 'id' => "username", 'class' => 'form-control'], set_value('username')) ?>
					<span class="help-block"><?= form_error('username') ?></span>
				</div>
			</div>
		</div>
		<div class="col-12">
			<div class=" form-group form-inline">
				<?= form_label("Mot de passe&nbsp;:", "password", ['class' => "col-md-3 control-label"]) ?>
				<div class="col-md-8 <?= empty(form_error('password')) ? "" : "has-error" ?>">
					<?= form_password(['name' => "password", 'id' => "password", 'class' => 'form-control'], set_value('password')) ?>
					<span class="help-block"><?= form_error('password') ?></span>
				</div>
			</div>
		</div>
		<div class="form-group form-inline">
			<div class="col-md-offset-2 col-md-10">
				<?= form_submit("send", "Envoyer", ['class' => "btn btn-outline-dark"]) ?>
			</div>
		</div>
		<?= form_close() ?>
	</div>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-6 text-center">
			<button type="submit" class="btn"><?= anchor('resetpassword', "Mot de passe oublié") ?></button>
		</div>
		<div class="col-6 text-center">
			<button type="submit" class="btn"><?= anchor('inscription', "Inscription") ?></button>
		</div>
	</div>
</div>
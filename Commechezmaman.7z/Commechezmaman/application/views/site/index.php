<div class="jumbotron">
	<div class="container justify-content-center">
		<h3><?= $title ?></h3>
		<p>Bienvenue sur notre recueil de recette familiale</p>
	</div>
</div>
<div class="card-deck">
	<div class="card">
		<img src="assets/images/Paella.jpg" class="card-img-top" alt="...">
		<div class="card-body">
			<h5 class="card-title">Titre recette</h5>
		</div>
	</div>
	<div class="card">
		<img src="assets/images/Paella.jpg" class="card-img-top" alt="...">
		<div class="card-body">
			<h5 class="card-title">Titre recette</h5>
		</div>
	</div>
	<div class="card">
		<img src="assets/images/Paella.jpg" class="card-img-top" alt="...">
		<div class="card-body">
			<h5 class="card-title">Titre recette</h5>
		</div>
	</div>
</div>



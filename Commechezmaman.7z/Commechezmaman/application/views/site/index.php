<div class="jumbotron">
	<div class="container">
		<h3><?= $title ?></h3>
		<p>Bienvenue sur notre recueil de recette familiale</p>
	</div>
</div>
<div class="wy-text-center">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, aperiam autem cum cupiditate delectus dolor doloremque doloribus enim magnam, mollitia nisi obcaecati officiis, porro praesentium qui quis recusandae rerum.</p>
</div>



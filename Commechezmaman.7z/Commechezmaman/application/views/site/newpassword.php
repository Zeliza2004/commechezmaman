<div class="container text-center py-5">

	<h1><?= $title ?></h1>
</div>


<div class="container">
	<div class="col-12">
		<!-- dans l'url il faudra retrouver l'id et le token en GET, et les données du formulaire en POST -->
		<form action="newpassword?id=<?=$id?>&token=<?$token?>" method="post">
			<div class="container">
				<label for="pwd"><b>Mot de passe *</b></label>
				<input type="password" placeholder="Entrez votre mot de passe" name="pwd" required>
				<label for="pwd2"><b>Saisissez à nouveau votre mot de passe *</b></label>
				<input type="password" placeholder="Entrez votre mot de passe" name="pwd2" required>
				<?php if ($error_message != null ) { // en cas d'erreur, on l'affiche ?>
					<div class="alert alert-danger"><?= $error_message ?></div>
				<?php } else if ($valid_message != null) { // si la réinitialisation a réussi on l'indique aussi à l'utilisateur ?>
					<div class="alert alert-info"><?= $valid_message ?></div>
				<?php } ?>
				<button type="submit">Modifier</button>
			</div>
		</form>
	</div>
</div>

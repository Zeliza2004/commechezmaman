<div class="container">
	<div class="row">
		<h1><?= $title ?></h1>
	</div>
	<div class="row">
		<?=form_open('inscription', ['class' => 'form-horizontal'])?>

	<div class="form-group">
		<?= form_label("Nom utilisateur&nbsp;:", "nom", ['class' => "col-md-2 control-label"]) ?>
		<div class="col-md-10 <?= empty(form_error('nom')) ? "" : "has-error" ?>">
			<span class="help-block"><?= form_error('nom') ?></span>
		<?= form_input(['name' => "nom", 'id' => "nom", 'class' => 'form-control'], set_value('nom')) ?>
	</div>

		<div class="form-group">
			<?= form_label("Prénom utilisateur&nbsp;:", "prenom", ['class' => "col-md-2 control-label"]) ?>
			<div class="col-md-10 <?= empty(form_error('prenom')) ? "" : "has-error" ?>">
				<span class="help-block"><?= form_error('prenom') ?></span>
				<?= form_input(['name' => "prenom", 'id' => "prenom", 'class' => 'form-control'], set_value('prenom')) ?>
			</div>
		<div class="form-group">
			<?= form_label("Mail&nbsp;:", "Adresse_mail", ['class' => "col-md-2 control-label"]) ?>
			<div class="col-md-10 <?= empty(form_error('Adresse_mail')) ? "" : "has-error" ?>">
			<span class="help-block"><?= form_error('Adresse_mail') ?></span>
			<?= form_input(['name' => "Adresse_mail", 'id' => "Adresse_mail", 'class' => 'form-control'], set_value('mail')) ?>
		</div>
		<div class="form-group ">
			<?= form_label("Mot de passe&nbsp;:", "password", ['class' => "col-md-2 control-label"]) ?>
			<div class="col-md-10 <?= empty(form_error('password')) ? "" : "has-error" ?>">
			<span class="help-block"><?= form_error('password') ?></span>
			<?= form_input(['type'=>'password', 'name'=> "password", 'id' => "password", 'class' => 'form-control'], set_value('password')) ?>
		</div>

		<div class="form-group ">
			<?= form_label("Confirmer mot de passe&nbsp;:", "password2", ['class' => "col-md-2 control-label"]) ?>
			<div class="col-md-10 <?= empty(form_error('password2')) ? "" : "has-error" ?>">
			<span class="help-block"><?= form_error('password2') ?></span>
			<?= form_input(['type'=>'password', 'name' => "password2", 'id' => "password2", 'class' => 'form-control'], set_value('password2')) ?>
		</div>

	<div class=form-group">
				<label>
					<input type="checkbox" name="rgpd"> Je reconnais avoir pris connaissance des conditions d’utilisation et y adhère totalement
				</label>
	</div>
			<div class="form-group">
				<div class="col-md-offset-2 col-md-10">
					<?= form_submit("send", "S'inscrire", ['class' => "btn btn-default btn-block"])?>
				</div>
			</div>

			</div
		</div>
	</div>
</div>
<!-- //main -->


<div class="container text-center py-5">

	<h1><?= $title ?></h1>
</div>

<div class="container-fluid">
	<div class="col-12">
		<form action="resetpassword.php" method="post">

			<div class="container-fluid">
				<label for="username"><b>Email</b></label>
				<input type="email" class="col-6" placeholder="Entrez votre email" name="username" required>

				<button type="submit" class="resetpassword">Réinitialiser le mot de passe</button>
			</div>
		</form>
	</div>
</div>

<div class="container">
	<h1><?= $title ?></h1>

</div>

<form method="post" name="recettes" action="">
	<div class="container">

		<div class="form-group">
			<?= form_label("Nom recette&nbsp;:", "nom_recette", ['class' => "col-md-2 control-label"]) ?>
			<div class="col-md-10 <?= empty(form_error('nom')) ? "" : "has-error" ?>">
				<span class="help-block"><?= form_error('nom') ?></span>
				<?= form_input(['name' => "nom_recette", 'id' => "nom_recette", 'class' => 'form-control'], set_value('nom_recette')) ?>
			</div>
			<div class="form-group">
				<input type="hidden" name="MAX_FILE_SIZE" value="100000">
				<?= form_label("Fichier :", "image", ['class' => "col-md-2 control-label"]) ?>
				<input type="file" name='image'>
				<input type="submit" name="envoyer" value="Envoyer le fichier">
			</div>
			<table class="table">
				<thead>
				<tr>
					<th class="text-center">Nom de l'ingrédient</th>
					<th class="text-center">Quantité</th>
					<th class="text-center">Unité de mesure</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td>
						<div class="form-group">
							<?= form_label("", "ingredient", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('ingredient')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('ingredient') ?></span>
								<?= form_input(['name' => "ingredient1", 'id' => "ingredient", 'class' => 'form-control'], set_value('ingredient')) ?>
							</div>
						</div>
					</td>

					<td>
						<div class="form-group">
							<?= form_label("", "grammage", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('grammage')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('grammage') ?></span>
								<?= form_input(['name' => "quantite1", 'id' => "grammage", 'class' => 'form-control'], set_value('grammage')) ?>
							</div>
						</div>
					</td>
					<td>
						<div class="form-group">
							<?= form_label("", "unite_de_mesure", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('unite_de_mesure')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('unite_de_mesure') ?></span>
								<?= form_input(['name' => "unite_de_mesure1", 'id' => "unite_de_mesure", 'class' => 'form-control'], set_value('unite_de_mesure')) ?>
							</div>
						</div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="form-group">
							<?= form_label("", "ingredient", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('ingredient')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('ingredient') ?></span>
								<?= form_input(['name' => "ingredient2", 'id' => "ingredient", 'class' => 'form-control'], set_value('ingredient')) ?>
							</div>
						</div>
					</td>

					<td>
						<div class="form-group">
							<?= form_label("", "grammage", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('grammage')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('grammage') ?></span>
								<?= form_input(['name' => "quantite2", 'id' => "grammage", 'class' => 'form-control'], set_value('grammage')) ?>
							</div>
						</div>
					</td>
					<td>
						<div class="form-group">
							<?= form_label("", "unite_de_mesure", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('unite_de_mesure')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('unite_de_mesure') ?></span>
								<?= form_input(['name' => "unite_de_mesure2", 'id' => "unite_de_mesure", 'class' => 'form-control'], set_value('unite_de_mesure')) ?>
							</div>
						</div>
					</td>
				</tr>

				<tr>
					<td>
						<div class="form-group">
							<?= form_label("", "ingredient", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('ingredient')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('ingredient') ?></span>
								<?= form_input(['name' => "ingredient3", 'id' => "ingredient", 'class' => 'form-control'], set_value('ingredient')) ?>
							</div>
						</div>
					</td>

					<td>
						<div class="form-group">
							<?= form_label("", "grammage", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('grammage')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('grammage') ?></span>
								<?= form_input(['name' => "quantite3", 'id' => "grammage", 'class' => 'form-control'], set_value('grammage')) ?>
							</div>
						</div>
					</td>
					<td>
						<div class="form-group">
							<?= form_label("", "unite_de_mesure", ['class' => "col-md-2 control-label"]) ?>
							<div class="col-md-10 <?= empty(form_error('unite_de_mesure')) ? "" : "has-error" ?>">
								<span class="help-block"><?= form_error('unite_de_mesure') ?></span>
								<?= form_input(['name' => "unite_de_mesure3", 'id' => "unite_de_mesure", 'class' => 'form-control'], set_value('unite_de_mesure')) ?>
							</div>
						</div>
					</td>
				</tr>

				</tbody>
			</table>
			<button type="button" class="btn btn-secondary">Ajouter une ligne</button>
		</div>
		<div class="container">
			<h1 class="">Etapes de la recette</h1>
			<div class="row">
				<table class="table">
					<tbody>
					<tr>

						<td>
							<div class="form-group">
								<?= form_label("", "etapesrecette", ['class' => " "]) ?>
								<div class="col-md-8 <?= empty(form_error('etapesrecette')) ? "" : "has-error" ?>">
									<span class="help-block"><?= form_error('etapesrecette') ?></span>
									<?= form_input(['name' => "etapesrecette1", 'id' => "etapesrecette", 'class' => 'form-control'], set_value('etapesrecette')) ?>
								</div>
							</div>
						</td>
					</tr>
					<tr>

						<td>
							<div class="form-group">
								<?= form_label("", "etapesrecette", ['class' => "control-label"]) ?>
								<div class="col-md-8 <?= empty(form_error('etapesrecette')) ? "" : "has-error" ?>">
									<span class="help-block"><?= form_error('etapesrecette') ?></span>
									<?= form_input(['name' => "etapesrecette2", 'id' => "etapesrecette", 'class' => 'form-control'], set_value('etapesrecette')) ?>
								</div>
							</div>
						</td>
					</tr>
					<tr>

						<td>
							<div class="form-group">
								<?= form_label("", "etapesrecette", ['class' => "control-label"]) ?>
								<div class="col-md-8 <?= empty(form_error('etapesrecette')) ? "" : "has-error" ?>">
									<span class="help-block"><?= form_error('etapesrecette') ?></span>
									<?= form_input(['name' => "etapesrecette3", 'id' => "etapesrecette", 'class' => 'form-control'], set_value('etapesrecette')) ?>
								</div>
							</div>
						</td>
					</tr>
					</tbody>
				</table>
				<button type="button" class="btn btn-secondary ">Ajouter une ligne</button>
			</div>
		</div>
		<div class="form-group">
			<div class="col-md-offset-2 col-md-10">
				<?= form_submit("send", "Envoyer", ['class' => "btn btn-default btn-block"])?>
			</div>
		</div>
</form>

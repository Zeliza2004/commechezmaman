<div class="container">
	<h1>Nom de la recette</h1>
	<div class="row">

		<div class="col-md-8">
			<table class="table table-striped">
		<tr>
			<th>nom de l'ingrédients</th>
			<th>grammage</th>
			<th>unité de mesure</th>
		</tr>

				<?php
				$recette = new Recette();
				$result = $recette->ingredientrecette($id_recette);
				if(!empty($result)) { foreach($result as $ingredientrecette) {?>
					<tr>
						<td><?php echo $ingredientrecette['ingredient'] ?></td>
						<td><?php echo $ingredientrecette['grammage'] ?></td>
						<td><?php echo $ingredientrecette['unité_de_mesure'] ?></td>
					</tr>
				<?php }  } else {?>

				<?php } ?>
			</table>
		</div>
	</div>
</div>

<div class="container">
	<h1>Etapes de la recette</h1>
	<table class="table">
		<?php if(!empty($etaperecette)) { foreach($etaperecette as $etaperecette) {?>
			<tr>
				<td><?php echo $etaperecette['ingredient'] ?></td>
				<td><?php echo $etaperecette['grammage'] ?></td>
				<td><?php echo $etaperecette['unité_de_mesure'] ?></td>
			</tr>
		<?php }  } else {?>

		<?php } ?>
	</table>
</div>

</form>

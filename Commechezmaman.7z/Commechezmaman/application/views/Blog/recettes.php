<div class="container">
	<h1>Nom de la recette</h1>
	<table class="table">
		<thead>
		<tr>
			<th>nom de l'ingrédients</th>
			<th>grammage</th>
			<th>unité de mesure</th>
		</tr>
		</thead>
		<tbody>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		</tbody>
	</table>
</div>
<div class="container">
	<h1>Etapes de la recette</h1>
	<table class="table">
		<tbody>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<div class="input-group input-group-lg">
					<input type="text" class="form-control" aria-label="Large" aria-describedby="inputGroup-sizing-sm">
				</div>
			</td>
		</tr>
		</tbody>
	</table>
</div>
<button>Ajouter</button>
</form>

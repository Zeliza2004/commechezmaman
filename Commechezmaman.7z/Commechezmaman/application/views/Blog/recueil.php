
<div class="container">
	<h1><?= $title ?></h1>
	<p>Bienvenue sur notre recueil de recette familiale</p>
</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-6">

		<div class="col-6">
<form class="form-inline my-2 my-lg-0">
	<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
	<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
</form>
		</div>
	</div>
</div>

<div class="cntainer">
	<table>
	<tr>
		<td><button type="button" class="btn btn-link">A</button></td>
		<td><button type="button" class="btn btn-link">J</button></td>
		<td><button type="button" class="btn btn-link">S</button></td>
	</tr>
		<tr>
			<td><button type="button" class="btn btn-link">B</button></td>
			<td><button type="button" class="btn btn-link">K</button></td>
			<td><button type="button" class="btn btn-link">T</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">C</button></td>
			<td><button type="button" class="btn btn-link">L</button></td>
			<td><button type="button" class="btn btn-link">U</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">D</button></td>
			<td><button type="button" class="btn btn-link">M</button></td>
			<td><button type="button" class="btn btn-link">V</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">E</button></td>
			<td><button type="button" class="btn btn-link">N</button></td>
			<td><button type="button" class="btn btn-link">W</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">F</button></td>
			<td><button type="button" class="btn btn-link">O</button></td>
			<td><button type="button" class="btn btn-link">X</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">G</button></td>
			<td><button type="button" class="btn btn-link">P</button></td>
			<td><button type="button" class="btn btn-link">Y</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">H</button></td>
			<td><button type="button" class="btn btn-link">Q</button></td>
			<td><button type="button" class="btn btn-link">Z</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">I</button></td>
			<td><button type="button" class="btn btn-link">R</button></td>
			<td></td>
		</tr>

	</table>
</div>

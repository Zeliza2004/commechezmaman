<div class="container text-center py-5">
	<h1><?= $title ?></h1>
	<p>Bienvenue sur notre recueil de recette familiale</p>
</div>

<div class="container py-5">
	<div class="row justify-content-end">
	<form class="form-inline my-2 my-lg-0">
		<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
	</form>
	</div>
</div>


<div class="row justify-content-center">
	<div class="col-auto">
		<table class="table table-responsive">
	<tr>
		<td><button type="button" class="btn btn-link">A</button></td>
		<td><button type="button" class="btn btn-link">F</button></td>
		<td><button type="button" class="btn btn-link">K</button></td>
		<td><button type="button" class="btn btn-link">P</button></td>
		<td><button type="button" class="btn btn-link">U</button></td>
		<td><button type="button" class="btn btn-link">Z</button></td>

	</tr>
		<tr>
			<td><button type="button" class="btn btn-link">B</button></td>
			<td><button type="button" class="btn btn-link">G</button></td>
			<td><button type="button" class="btn btn-link">L</button></td>
			<td><button type="button" class="btn btn-link">Q</button></td>
			<td><button type="button" class="btn btn-link">V</button></td>
		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">C</button></td>
			<td><button type="button" class="btn btn-link">H</button></td>
			<td><button type="button" class="btn btn-link">M</button></td>
			<td><button type="button" class="btn btn-link">R</button></td>
			<td><button type="button" class="btn btn-link">W</button></td>

		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">D</button></td>
			<td><button type="button" class="btn btn-link">I</button></td>
			<td><button type="button" class="btn btn-link">N</button></td>
			<td><button type="button" class="btn btn-link">S</button></td>
			<td><button type="button" class="btn btn-link">X</button></td>

		</tr>
		<tr>
			<td><button type="button" class="btn btn-link">E</button></td>
			<td><button type="button" class="btn btn-link">J</button></td>
			<td><button type="button" class="btn btn-link">O</button></td>
			<td><button type="button" class="btn btn-link">T</button></td>
			<td><button type="button" class="btn btn-link">Y</button></td>

		</tr>


		</table>
	</div>
</div>

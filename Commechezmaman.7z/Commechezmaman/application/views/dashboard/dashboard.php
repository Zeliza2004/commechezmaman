<div class="container">
	<h1><?= $title ?></h1>
		</div>
</div>
<div class="container">
			<h3 class="text-center py-5">Interface utilisateur</h3>

	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, dolore id incidunt neque saepe temporibus velit voluptas voluptates! Accusamus ipsam minima officia placeat quibusdam repellendus rerum sint tempora vitae voluptates?</p>

</div>

<div class="container">
	<h3 class="text-center py-5">Mes favoris</h3>

	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, dolore id incidunt neque saepe temporibus velit voluptas voluptates! Accusamus ipsam minima officia placeat quibusdam repellendus rerum sint tempora vitae voluptates?</p>

</div>




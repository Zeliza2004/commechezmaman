<div class="container">
	<div class="row">
		<?= heading($title) ?>
		<hr/>
	</div>
	<div class="row">
		<h3 class="align-center">Interface utilisateur</h3>
		<h1 class="align-center">Mes données</h1>
	</div>
</div>


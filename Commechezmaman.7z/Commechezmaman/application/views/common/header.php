<!DOCTYPE html>
<html>
<head>
	<? meta('UTF-8', '', 'charset'); ?>
	<? meta("X-UA-Compatible", "IE=edge", 'http-equiv'); ?>
	<? meta("viewport", "width=device-width, initial-scale=1"); ?>
	<title><?= $title ?></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
		  integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<link type="text/css" rel="stylesheet" href="<?= base_url("assets/css/style.css") ?>">

</head>
<body>
<header>
	<div class="jumbotron jumbotron-fluid" id="header_image">

		<div class="container">
			<h1 class="display-5 text-uppercase strong text-center text-light" id="maman">Comme chez maman</h1>
		</div>
	</div>
		<!--  version mobile -->
		<nav class="navbar navbar-expand-lg">
			<button type="button" class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#main_nav" aria-expanded="false" id="nav_button"  aria-label="Toggle navigation">
				<span class="sr-only">Menu</span>
				<span class="navbar-toggler-icon"></span>
				<span class="navbar-toggler-icon"></span>
				<span class="navbar-toggler-icon"></span>
			</button>
		<!--  version mobile -->
			<div class="collapse navbar-collapse" id="main_nav">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item mr-lg-5"><a><?= anchor('index', "Accueil"); ?></a></li>
					<li class="nav-item mr-lg-5"><a><?= anchor('Recueilderecette', "Recueil de recette") ?></a></li>
					<?php if ($this->auth_user->is_connected) : ?>
						<li class="nav-item mr-lg-5"><a><?= anchor('ajoutrecette', "Ajouter une recette") ?></a></li>
						<li class="nav-item mr-lg-5"><a><?= anchor('panneau_de_controle/index', "Panneau de contrôle") ?></a></li>
					<?php endif; ?>
					<li class="nav-item mr-lg-5"><a><?= anchor('contact', "Contact") ?></a></li>
				</ul>
				<ul class="navbar-nav text-right">
					<?php if ($this->auth_user->is_connected) : ?>
						<li class="nav-item"><a><?= anchor('deconnexion', "Déconnexion") ?></a></li>
					<?php else : ?>
						<li class="nav-item"><a><?= anchor('connexion', " Connexion") ?></a></li>
					<?php endif; ?>
				</ul>
			</div>
		</nav>
</header>


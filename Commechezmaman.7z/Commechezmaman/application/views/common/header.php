<!DOCTYPE html>
<html>
<head>
	<? meta('UTF-8', '', 'charset'); ?>
	<? meta("X-UA-Compatible", "IE=edge", 'http-equiv'); ?>
	<? meta("viewport", "width=device-width, initial-scale=1");?>
	<title><?= $title ?></title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>	<link rel="stylesheet" type="text/css" href="<?= base_url("assets/css/style.css") ?>">

</head>
<body>
<header>
	<div class="jumbotron jumbotron-fluid">
		<div class="bg-jumb-main">
			<div class="container">
				<h1 class="display-5 text-uppercase strong text-center" id="maman">Comme chez maman</h1>
			</div>
		</div>
		<div class="navbar">
			<!--  version mobile -->
			<nav class="navbar  justify-content-center">
				<div class="navbar-header ">
					<button type="button" class="navbar-toggle collapsed " data-toggle="collapse" data-target="#main_nav" aria-expanded="false" id="button">
						<span class="sr-only">Menu</span>
						<span class="icon-bar bg-white"></span>
						<span class="icon-bar bg-white"></span>
						<span class="icon-bar bg-white"></span>
					</button>
					<!--  version mobile -->
				</div>
				<div class="collapse navbar-collapse" id="main_nav">
					<ul class="nav navbar-nav fixed-bottom">
						<li><?= anchor('index', "Accueil"); ?></li>

						<li><?= anchor('Recueilderecette', "Recueil de recette")?></li>
						<?php if ($this->auth_user->is_connected) : ?>
							<li><?= anchor('ajoutrecette', "Ajouter une recette")?></li>
							<li><?= anchor('panneau_de_controle/index', "Panneau de contrôle")?></li>
						<?php endif; ?>
						<li><?= anchor('contact', "Contact") ?></li>
					</ul>
					<ul class="nav navbar-nav navbar-right fixed-bottom">
						<?php if ($this->auth_user->is_connected) : ?>
							<li><?= anchor('deconnexion', "Déconnexion") ?></li>
						<?php else : ?>
							<li><?= anchor('connexion', "Connexion") ?></li>
						<?php endif; ?>
					</ul>
					<?php if ($this->auth_user->is_connected) : ?>
						<p class="navbar-text navbar-right">|</p>
						<p class="navbar-text navbar-right">Bienvenue <strong><?= $this->auth_user->username ?></strong></p>
					<?php endif; ?>
				</div>
		</div>
	</div>

</header>
<script>

</script>
